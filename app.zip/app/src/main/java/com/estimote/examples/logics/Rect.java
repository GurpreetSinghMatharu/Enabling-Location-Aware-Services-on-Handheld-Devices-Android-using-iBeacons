package com.estimote.examples.logics;

public class Rect {
	int x;//xmin
	int y;//ymin
	int width;
	int height;
	public String prefix = "";
	public Rect(int px,int py, int pw, int ph){
		x = px;
		y = py;
		width = pw;
		height = ph;
//		if(x<0 || x >= Network.x_range || y <0 || y >= Network.y_range
//		|| pw <0 || ph <0){
//			System.out.println(prefix + "\terror in constructing rect");
//			System.out.println(x + "," + y + "," + width + "," + height);
//		}
	}
	public String toString(){
		return "Rect[" + "x=" + x + ",y=" + y + ",width=" + width + ",height=" +height + "]";
	}
}
