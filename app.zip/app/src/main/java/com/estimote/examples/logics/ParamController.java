package com.estimote.examples.logics;

import java.util.*;
public class ParamController {
	String paramName;
	int curParamidx = 0;
	int[] paramInt;
	double[] paramDouble;
	private ParamController(String pname){
		//add params for sd
		paramName = pname;
		paramInt = null;
		paramDouble = null;
	}
	public void setParamInt(int[] param){
		paramInt = param;
	}
	public void setParamDouble(double[] param){
		paramDouble = param;
		
		
	}
	public boolean getParam(Input in){
		if(!paramName.equalsIgnoreCase("doi") && !paramName.equalsIgnoreCase("d")){
			//sd, nd, or vmax
			if(curParamidx >= paramInt.length)
				return true;
			else{
				in.setParameter(paramName, Integer.toString(paramInt[curParamidx]));
				curParamidx++;
				return false;
			}
		}else{
			//doi or d
			if(curParamidx >= paramDouble.length)
				return true;
			else{
				in.setParameter(paramName, Double.toString(paramDouble[curParamidx]));
				curParamidx++;
				return false;
			}
		}
	}
	public static ParamController Generator(String name){
		ParamController ret = new ParamController(name);
		if(name.equalsIgnoreCase("seed_num")){
			int[] param = new int[]{4,8,12,16,20,24,28,32,36,40};
			ret.setParamInt(param);
		}else if(name.equalsIgnoreCase("node_num")){
			int[] param = new int[]{40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200};
			ret.setParamInt(param);
		}else if(name.equalsIgnoreCase("max_v")){
			int[] param = new int[]{0,1,2,4,8,12,16,20,24,28,32,36,40,50,75,100,150,200,250,300,350};
			ret.setParamInt(param);
		}else if(name.equalsIgnoreCase("doi")){
			double[] param = new double[]{0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5};
			ret.setParamDouble(param);
		}else if(name.equalsIgnoreCase("d")){
			double[] param = new double[]{0.95,0.9,0.85,0.8,0.75,0.7,0.65,0.6,0.55,0.5};
			ret.setParamDouble(param);
		}else if(name.equalsIgnoreCase("addition")){
			int[] param = new int[]{5,10,15,20,25,30,35,40};
			ret.paramName = "max_v";
			ret.setParamInt(param);
		}else if(name.equalsIgnoreCase("mcwaddition")){
			int[] param = new int[]{5,10,15,20,25,30,35,40};
			ret.setParamInt(param);
		}else if(name.equalsIgnoreCase("staticsim")){
			int[] param = new int[]{5};
			ret.paramName = "max_v";
			ret.setParamInt(param);			
		}
		return ret;
	}
}
