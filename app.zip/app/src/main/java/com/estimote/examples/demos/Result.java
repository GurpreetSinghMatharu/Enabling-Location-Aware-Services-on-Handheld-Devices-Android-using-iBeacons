package com.estimote.examples.demos;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.DoubleBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.RemoteException;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.estimote.sdk.Beacon;
import com.estimote.sdk.BeaconManager;
import com.estimote.sdk.Region;
import com.estimote.sdk.Utils;

public class Result extends Activity {

    private Beacon selectedBeacon;
    private String noOfTimes;
    private ArrayList<Double> distanceList = new ArrayList<Double>();
    private ArrayList<Integer> rssiList = new ArrayList<Integer>();
    private BeaconManager beaconManager;
    private static final int REQUEST_ENABLE_BT = 1234;
    private static final Region ALL_ESTIMOTE_BEACONS_REGION = new Region("rid", null, null, null);
    private int noOfTimesInt;
    private ProgressBar progressBar;
    private Button moreReadings,btnMail;
    private TextView noOfTimesTxtView, distanceValues, averageDistanceValues, rssiValues, averageRssiValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resut);

        moreReadings = (Button)findViewById(R.id.BtnMoreReading);
        moreReadings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopIbeacon();
                startActivity(new Intent(Result.this,AllDemosActivity.class));
            }
        });

        btnMail = (Button)findViewById(R.id.btnMail);
        btnMail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMail();
            }
        });

        progressBar = new ProgressBar(this){
            @Override
            public void onDismiss() {

            }
        };
        progressBar.show();

        getExtras();

        noOfTimesInt = Integer.valueOf(noOfTimes)*3;

        noOfTimesTxtView = (TextView)findViewById(R.id.textView);
        distanceValues = (TextView)findViewById(R.id.textView1);
        averageDistanceValues = (TextView)findViewById(R.id.textView2);
        rssiValues = (TextView)findViewById(R.id.textView3);
        averageRssiValues = (TextView)findViewById(R.id.textView4);

        doTask();
    }

    private void sendMail(){
        Intent emailIntent = new Intent(Intent.ACTION_SEND_MULTIPLE);
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[] {""});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "iBeacon Tracker Result");

        StringBuffer body = new StringBuffer();

        body.append("Number of Readings: " + Integer.valueOf(noOfTimes));

        StringBuffer distanceBuffer = new StringBuffer();
        distanceBuffer.append("Initial Distance Values: ");
        distanceBuffer.append(System.getProperty("line.separator"));
        ArrayList<Double> finalDistanceArray = new ArrayList<>();
        for(int i=0;i<distanceList.size()/3;i++){
            finalDistanceArray.add(distanceList.get(i));
            distanceBuffer.append(distanceList.get(i));
            distanceBuffer.append(System.getProperty("line.separator"));
        }
        distanceBuffer.append("Final Distance Values: ");
        distanceBuffer.append(System.getProperty("line.separator"));
        ArrayList<Double> arrayList = removeDuplicatesDouble(finalDistanceArray);
        for(int i=0;i<arrayList.size();i++){
            distanceBuffer.append(arrayList.get(i));
            distanceBuffer.append(System.getProperty("line.separator"));
        }
        body.append(distanceBuffer.toString());

        StringBuffer averageDistanceBuffer = new StringBuffer();
        averageDistanceBuffer.append("Initial Average Distance Value: ");
        averageDistanceBuffer.append(System.getProperty("line.separator"));
        averageDistanceBuffer.append(getAverageDistance(finalDistanceArray));
        averageDistanceBuffer.append(System.getProperty("line.separator"));
        averageDistanceBuffer.append("Final Average Distance Value: ");
        averageDistanceBuffer.append(getAverageDistance(removeDuplicatesDouble(finalDistanceArray)));
        body.append(averageDistanceBuffer.toString());

        StringBuffer rssiValueBuffer = new StringBuffer();
        rssiValueBuffer.append("Initial RSSI Values: ");
        rssiValueBuffer.append(System.getProperty("line.separator"));
        ArrayList<Integer> finalRssiArray = new ArrayList<>();
        for(int i=0;i<rssiList.size()/3;i++){
            finalRssiArray.add(rssiList.get(i));
            rssiValueBuffer.append(rssiList.get(i));
            rssiValueBuffer.append(System.getProperty("line.separator"));
        }
        rssiValueBuffer.append("Final RSSI Values: ");
        rssiValueBuffer.append(System.getProperty("line.separator"));
        ArrayList<Integer> arrayList1 = removeDuplicatesInteger(finalRssiArray);
        for(int i=0;i<arrayList1.size();i++){
            rssiValueBuffer.append(arrayList1.get(i));
            rssiValueBuffer.append(System.getProperty("line.separator"));
        }
       body.append(rssiValueBuffer.toString());

        StringBuffer averageRssiBuffer = new StringBuffer();
        averageRssiBuffer.append("Initial Average RSSI Value: ");
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(getAverageRssi(finalRssiArray));
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append("Final Average Distance Value: ");
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(getAverageRssi(removeDuplicatesInteger(finalRssiArray)));
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append("Distance computed using iBLA Localization Algorithm: ");
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(getAverageDistance(distanceList));
        body.append(averageRssiBuffer.toString());

        emailIntent.putExtra(Intent.EXTRA_TEXT,body.toString());
        startActivity(Intent.createChooser(emailIntent, "Pick an Email provider"));
    }

    public static String getFormatedDate(String dateString, String datePattern, String convertPattern){
        Date date = parseDate(dateString, datePattern,false);
        return formatDate(date, convertPattern);
    }

    public static  Date parseDate(String dateString,String pattern, boolean isAppendYear){
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat(pattern);
        try {
            Date date= simpleDateFormat.parse(dateString);
            Calendar calendar=Calendar.getInstance();
            calendar.setTime(date);
            if(isAppendYear)
                calendar.add(Calendar.YEAR,44);
            return calendar.getTime();
        } catch (Exception e) {
            e.printStackTrace();
            return new Date();
        }
    }

    public static  String formatDate(Date date,String pattern){
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat(pattern);
        return simpleDateFormat.format(date);
    }

    private void writeToFile(){
       try{
           File root = new File(Environment.getExternalStorageDirectory(), "ibeacon Tracker");
           if (!root.exists())
            root.mkdirs();
           File gpxfile = new File(root, "Backup_file.txt");
           if(!gpxfile.exists())
               gpxfile.createNewFile();
           FileWriter writer = new FileWriter(gpxfile);
           StringBuffer body = new StringBuffer();

           body.append("Number of Readings: " + Integer.valueOf(noOfTimes));

           StringBuffer distanceBuffer = new StringBuffer();
           distanceBuffer.append("Initial Distance Values: ");
           distanceBuffer.append(System.getProperty("line.separator"));
           ArrayList<Double> finalDistanceArray = new ArrayList<>();
           for(int i=0;i<distanceList.size()/3;i++){
               finalDistanceArray.add(distanceList.get(i));
               distanceBuffer.append(distanceList.get(i));
               distanceBuffer.append(System.getProperty("line.separator"));
           }
           distanceBuffer.append("Final Distance Values: ");
           distanceBuffer.append(System.getProperty("line.separator"));
           ArrayList<Double> arrayList = removeDuplicatesDouble(finalDistanceArray);
           for(int i=0;i<arrayList.size();i++){
               distanceBuffer.append(arrayList.get(i));
               distanceBuffer.append(System.getProperty("line.separator"));
           }
           body.append(distanceBuffer.toString());

           StringBuffer averageDistanceBuffer = new StringBuffer();
           averageDistanceBuffer.append("Initial Average Distance Value: ");
           averageDistanceBuffer.append(System.getProperty("line.separator"));
           averageDistanceBuffer.append(getAverageDistance(finalDistanceArray));
           averageDistanceBuffer.append(System.getProperty("line.separator"));
           averageDistanceBuffer.append("Final Average Distance Value: ");
           averageDistanceBuffer.append(getAverageDistance(removeDuplicatesDouble(finalDistanceArray)));
           body.append(averageDistanceBuffer.toString());

           StringBuffer rssiValueBuffer = new StringBuffer();
           rssiValueBuffer.append("Initial RSSI Values: ");
           rssiValueBuffer.append(System.getProperty("line.separator"));
           ArrayList<Integer> finalRssiArray = new ArrayList<>();
           for(int i=0;i<rssiList.size()/3;i++){
               finalRssiArray.add(rssiList.get(i));
               rssiValueBuffer.append(rssiList.get(i));
               rssiValueBuffer.append(System.getProperty("line.separator"));
           }
           rssiValueBuffer.append("Final RSSI Values: ");
           rssiValueBuffer.append(System.getProperty("line.separator"));
           ArrayList<Integer> arrayList1 = removeDuplicatesInteger(finalRssiArray);
           for(int i=0;i<arrayList1.size();i++){
               rssiValueBuffer.append(arrayList1.get(i));
               rssiValueBuffer.append(System.getProperty("line.separator"));
           }
           body.append(rssiValueBuffer.toString());

           StringBuffer averageRssiBuffer = new StringBuffer();
           averageRssiBuffer.append("Initial Average RSSI Value: ");
           averageRssiBuffer.append(System.getProperty("line.separator"));
           averageRssiBuffer.append(getAverageRssi(finalRssiArray));
           averageRssiBuffer.append(System.getProperty("line.separator"));
           averageRssiBuffer.append("Final Average Distance Value: ");
           averageRssiBuffer.append(System.getProperty("line.separator"));
           averageRssiBuffer.append(getAverageRssi(removeDuplicatesInteger(finalRssiArray)));
           averageRssiBuffer.append(System.getProperty("line.separator"));
           averageRssiBuffer.append(System.getProperty("line.separator"));
           averageRssiBuffer.append(System.getProperty("line.separator"));
           averageRssiBuffer.append("Distance computed using iBLA Localization Algorithm: ");
           averageRssiBuffer.append(System.getProperty("line.separator"));
           averageRssiBuffer.append(getAverageDistance(distanceList));
           averageRssiBuffer.append(System.getProperty("line.separator"));
           body.append(averageRssiBuffer.toString());
           writer.append(body.toString());
           writer.flush();
           writer.close();
         }
      catch(IOException e){
         e.printStackTrace();
      }
    }

    private void showOutput(){

        noOfTimesTxtView.setText("Number of Readings: " + Integer.valueOf(noOfTimes));

        StringBuffer distanceBuffer = new StringBuffer();
        distanceBuffer.append("Initial Distance Values: ");
        distanceBuffer.append(System.getProperty("line.separator"));
        ArrayList<Double> finalDistanceArray = new ArrayList<>();
        for(int i=0;i<distanceList.size()/3;i++){
            finalDistanceArray.add(distanceList.get(i));
            distanceBuffer.append(distanceList.get(i));
            distanceBuffer.append(System.getProperty("line.separator"));
        }
        distanceBuffer.append("Final Distance Values: ");
        distanceBuffer.append(System.getProperty("line.separator"));
        ArrayList<Double> arrayList = removeDuplicatesDouble(finalDistanceArray);
        for(int i=0;i<arrayList.size();i++){
            distanceBuffer.append(arrayList.get(i));
            distanceBuffer.append(System.getProperty("line.separator"));
        }
        distanceValues.setText(distanceBuffer.toString());

        StringBuffer averageDistanceBuffer = new StringBuffer();
        averageDistanceBuffer.append("Initial Average Distance Value: ");
        averageDistanceBuffer.append(System.getProperty("line.separator"));
        averageDistanceBuffer.append(getAverageDistance(finalDistanceArray));
        averageDistanceBuffer.append(System.getProperty("line.separator"));
        averageDistanceBuffer.append("Final Average Distance Value: ");
        averageDistanceBuffer.append(getAverageDistance(removeDuplicatesDouble(finalDistanceArray)));
        averageDistanceValues.setText(averageDistanceBuffer.toString());

        StringBuffer rssiValueBuffer = new StringBuffer();
        rssiValueBuffer.append("Initial RSSI Values: ");
        rssiValueBuffer.append(System.getProperty("line.separator"));
        ArrayList<Integer> finalRssiArray = new ArrayList<>();
        for(int i=0;i<rssiList.size()/3;i++){
            finalRssiArray.add(rssiList.get(i));
            rssiValueBuffer.append(rssiList.get(i));
            rssiValueBuffer.append(System.getProperty("line.separator"));
        }
        rssiValueBuffer.append("Final RSSI Values: ");
        rssiValueBuffer.append(System.getProperty("line.separator"));
        ArrayList<Integer> arrayList1 = removeDuplicatesInteger(finalRssiArray);
        for(int i=0;i<arrayList1.size();i++){
            rssiValueBuffer.append(arrayList1.get(i));
            rssiValueBuffer.append(System.getProperty("line.separator"));
        }
        rssiValues.setText(rssiValueBuffer.toString());

        StringBuffer averageRssiBuffer = new StringBuffer();
        averageRssiBuffer.append("Initial Average RSSI Value: ");
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(getAverageRssi(finalRssiArray));
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append("Final Average Distance Value: ");
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(getAverageRssi(removeDuplicatesInteger(finalRssiArray)));
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append("Distance computed using iBLA Localization Algorithm: ");
        averageRssiBuffer.append(System.getProperty("line.separator"));
        averageRssiBuffer.append(getAverageDistance(distanceList));
        averageRssiValues.setText(averageRssiBuffer.toString());

        if(progressBar!=null && progressBar.isShowing())
            progressBar.dismiss();

        moreReadings.setVisibility(View.VISIBLE);
        btnMail.setVisibility(View.VISIBLE);

        writeToFile();

    }

    private void doTask(){
        startIbeacon();
    }

    private void startIbeacon(){
        beaconManager = new BeaconManager(this);
        beaconManager.setRangingListener(new BeaconManager.RangingListener() {
            @Override
            public void onBeaconsDiscovered(Region region, final List<Beacon> beacons) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for (Beacon rangedBeacon : beacons) {
                            try{
                                if (rangedBeacon.getMacAddress().equals(selectedBeacon.getMacAddress())) {
                                    selectedBeacon = rangedBeacon;
                                    distanceList.add(Utils.computeAccuracy(selectedBeacon));
                                    rssiList.add(selectedBeacon.getRssi());
                                    noOfTimesInt = noOfTimesInt-1;
                                    if(noOfTimesInt==0){
                                        stopIbeacon();
                                        showOutput();
                                    }
                                }
                            }
                            catch (Exception e) {}
                        }
                    }
                });
            }
        });
        if (!beaconManager.hasBluetooth()) {
            Toast.makeText(this, "Device does not have Bluetooth Low Energy", Toast.LENGTH_LONG).show();
            return;
        }

        if (!beaconManager.isBluetoothEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            connectToService();
        }
    }

    private void stopIbeacon(){
        try {
            beaconManager.stopRanging(ALL_ESTIMOTE_BEACONS_REGION);
            beaconManager.disconnect();
        } catch (RemoteException e) {
        }
    }

    private void connectToService() {
        beaconManager.connect(new BeaconManager.ServiceReadyCallback() {
            @Override
            public void onServiceReady() {
                try {
                    beaconManager.startRanging(ALL_ESTIMOTE_BEACONS_REGION);
                } catch (RemoteException e) {}
            }
        });
    }

    private Double getAverageDistance(ArrayList<Double> arrayList){
        Double valuesSum=0.0;
        for(Double obj : arrayList)
            valuesSum = valuesSum+obj;
       Double averageValue = valuesSum/arrayList.size();
       return averageValue;
    }

    private Integer getAverageRssi(ArrayList<Integer> arrayList){
        Integer valuesSum=0;
        for(Integer obj : arrayList)
            valuesSum = valuesSum+obj;
        Integer averageValue = valuesSum/arrayList.size();
        return averageValue;
    }

    private void getExtras(){
        selectedBeacon = (Beacon)getIntent().getParcelableExtra("SELECTED_BEACON");
        noOfTimes = getIntent().getStringExtra("NO OF TIMES");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_OK) {
                connectToService();
            } else {
                Toast.makeText(this, "Bluetooth not enabled", Toast.LENGTH_LONG).show();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public  ArrayList<Integer> removeDuplicatesInteger(ArrayList<Integer> list){
        for(int i = 0 ; i < list.size() ; i++){
            boolean continueFlag = true;
            for( int j = i + 1; j < list.size() && continueFlag ; j = j){
                if(list.get(i).intValue() == list.get(j).intValue()){
                    list.remove(j);
                }
                else{
                    continueFlag = false;
                    j++;
                }
            }
        }
        return list;
    }

    public  ArrayList<Double> removeDuplicatesDouble(ArrayList<Double> list){
        for(int i = 0 ; i < list.size() ; i++){
            boolean continueFlag = true;
            for( int j = i + 1; j < list.size() && continueFlag ; j = j){
                if(list.get(i).intValue() == list.get(j).intValue()){
                    list.remove(j);
                }
                else{
                    continueFlag = false;
                    j++;
                }
            }
        }
        return list;
    }

}