package com.estimote.examples.demos;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.estimote.sdk.Beacon;

public class SelectOption extends Activity {

    EditText noOfTimes;
    Button start;
    Beacon beacon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option_selection);
        beacon = getIntent().getParcelableExtra(ListBeaconsActivity.EXTRAS_BEACON);
        noOfTimes = (EditText)findViewById(R.id.noOfTime);
        start = (Button)findViewById(R.id.startBtn);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (noOfTimes.getText().toString().trim().toString().equalsIgnoreCase("")) {
                    Toast.makeText(SelectOption.this, "Enter the Number of Readings & Click on Start", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(SelectOption.this, Result.class);
                    intent.putExtra("SELECTED_BEACON", beacon);
                    intent.putExtra("NO OF TIMES", noOfTimes.getText().toString());
                    startActivity(intent);
                }
            }
        });
    }

}
