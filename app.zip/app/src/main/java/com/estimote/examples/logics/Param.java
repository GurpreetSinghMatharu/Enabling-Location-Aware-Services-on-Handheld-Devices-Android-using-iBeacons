package com.estimote.examples.logics;

import java.io.*;
import java.util.StringTokenizer;

public class Param {
	String[] param;
	String[] value;
	int MAX_PARAM_NUM = 100;
	int MAX_LINE_LENGTH = 1024;
	int param_num;
	
	public Param(String fname){
		param = new String[MAX_PARAM_NUM];
		value = new String[MAX_PARAM_NUM];
		
		BufferedReader in;
		String line;
		StringTokenizer st;
		param_num = 0;
		try{
			in = new BufferedReader(new FileReader(fname));
			while((line = in.readLine()) != null){
				//delete comments
				for(int i = 0; i < line.length(); i++){
					if(line.charAt(i) == '#')
						line = line.substring(0,i);					
				}
				if(line.length() == 0)
					continue;
				line = line.trim();
				if(line.length() > 0){
					st = new StringTokenizer(line);
					param[param_num] = st.nextToken().trim();
					value[param_num] = st.nextToken().trim();
					param_num++;
				}
			}
			in.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void setParam(String pparam, String pvalue){
		for(int i = 0; i < param.length; i++){
			if(pparam.equalsIgnoreCase(param[i]))
				value[i] = pvalue;
		}
	}
	public String getParam(String pparam){
		for(int i = 0; i < param.length; i++){
			if(pparam.equalsIgnoreCase(param[i]))
				return value[i];
		}
		return null;
	}
}
