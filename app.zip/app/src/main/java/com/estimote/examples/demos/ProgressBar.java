package com.estimote.examples.demos;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

public abstract class ProgressBar extends ProgressDialog{
	Context context=null;

    public ProgressBar(Context context) {
		super(context);
		this.context=context;
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.progress_dialog);
		setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		setCanceledOnTouchOutside(false);

	}
	int backPressCount=0;
	@Override
	public void onBackPressed() {
	}
	
	@Override
	public void dismiss() {
		super.dismiss();
		onDismiss();
	};

	public abstract void onDismiss();
}