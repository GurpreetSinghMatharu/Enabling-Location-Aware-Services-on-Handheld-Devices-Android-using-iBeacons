package com.estimote.examples.logics; /**
 * 
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;

/**
 * @author Administrator
 *
 */
public class Input {
	 int MAX_LENGTH = 1024;
	    int MAX_LINE = 1000;
	    String token[];
	    String value[];
	    int token_num;
	    
	    public Input(String filename) {
	    	
	    	BufferedReader is;
	    	String inputLine;
	    	StringTokenizer st;


		token_num = 0;
		token = new String[MAX_LINE];
		value = new String[MAX_LINE];
		
	    	try {
		    is = new BufferedReader(new FileReader(filename)); 
		    int j = 0;
	            while ((inputLine = is.readLine()) != null) {
//	            	System.out.println("j is " + (j++));
//	            	System.out.println("read line " + inputLine);
	            	for (int i = 0; i < inputLine.length(); i++)
	            	    if (inputLine.charAt(i) == '#') /* comment */
	            	    	inputLine = inputLine.substring(0, i);
	            	if (inputLine.length() == 0)	/* blank line */
	            	    continue;
	            	inputLine = inputLine.trim();
	            	if (inputLine.length() > 0) {
	            	    st = new StringTokenizer(inputLine, "\t"); 
	            	    token[token_num] = st.nextToken().trim();
	            	    value[token_num] = st.nextToken().trim();
	            	    token_num++;
	            	}
//	            	System.out.println("read param " + token[token_num-1] + 
//	            			", value is " + value[token_num-1]);
	            }
	            is.close();	
	           
	        } catch (Exception e) {
	            System.err.println(e);
	        }   
	       
	    }
	    
	    public String getParameter(String name) {
	    	
	    	int i;
	    	
	    	for (i = 0; i < token_num; i++) {
	    	    if (token[i].equalsIgnoreCase(name))
	    	    	return (value[i]);
	    	}
	    	return null;
	    	
	    }
	    
	    public void setParameter(String name, String result) {
	    	
	    	int i;
	    	
	    	for (i = 0; i < token_num; i++) {
	    	    if (token[i].equalsIgnoreCase(name))
	    	    	value[i] = new String(result);
	    	}
	    }

}

